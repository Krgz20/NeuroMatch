// Firebase Config
const firebaseConfig = {
  apiKey: "AIzaSyBNYGvx8lvRZ7MaP_h1hbI0p0Bu10p-Y7Q",
  authDomain: "neuromatch1988.firebaseapp.com",
  projectId: "neuromatch1988",
  storageBucket: "neuromatch1988.appspot.com",
  messagingSenderId: "635135142528",
  appId: "1:635135142528:web:fb40acf824a3adaf7c5465"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// Switch Screens
function goToScreen(id) {
  document.querySelectorAll(".screen").forEach(screen => screen.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

// Sign Up
function signUpUser() {
  const email = document.getElementById("signup-email").value;
  const password = document.getElementById("signup-password").value;
  const confirm = document.getElementById("signup-confirm").value;

  if (password !== confirm) return alert("Passwords do not match!");

  auth.createUserWithEmailAndPassword(email, password)
    .then(() => {
      alert("Signup successful!");
      goToScreen('profile-screen');
    })
    .catch(err => alert(err.message));
}

// Save Profile
function saveProfile() {
  const user = auth.currentUser;
  if (!user) return alert("Please log in first.");

  const profile = {
    name: document.getElementById("name").value,
    bio: document.getElementById("bio").value,
    relationshipStatus: document.getElementById("relationship-status").value,
  };

  db.collection("users").doc(user.uid).set(profile)
    .then(() => alert("Profile saved!"))
    .catch(error => alert(error.message));
}

// Stripe Payment
function redirectToPayment() {
  window.location.href = "https://buy.stripe.com/test_cNi28q0ERd7Z7Py4vd1Fe00";
}

// Send Message
function sendMessage() {
  const input = document.getElementById("chat-input");
  const chatBox = document.getElementById("chat-box");
  if (input.value.trim()) {
    chatBox.innerHTML += `<div><strong>You:</strong> ${input.value}</div>`;
    input.value = "";
    chatBox.scrollTop = chatBox.scrollHeight;
  }
}

// Google Maps (Basic Example)
function initMap() {
  new google.maps.Map(document.getElementById("map"), {
    center: { lat: 51.5074, lng: -0.1278 },
    zoom: 12
  });
}

// Delete Account
function deleteAccount() {
  const user = auth.currentUser;
  if (user) {
    user.delete().then(() => {
      alert("Account deleted");
      goToScreen("signup-screen");
    }).catch(error => alert("Error: " + error.message));
  }
}

// Report
function submitReport() {
  alert("Report submitted. We will review this issue.");
}